package com.example.streetsmart;

import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.content.ContextCompat;
import androidx.room.jarjarred.org.antlr.v4.gui.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class MainActivity extends AppCompatActivity {

    private static final int INPUT_IMAGE_WIDTH = 224;
    private static final int INPUT_IMAGE_HEIGHT = 224;
    private static final int NUM_CLASSES = 2; // Assuming 2 classes: occupied and vacant
    private static final int CHANNELS = 3; // Assuming RGB color channels
    public Intptr interpreter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize TensorFlow Lite interpreter
        try {
            interpreter = new Interpreter(loadModelFile(getString(R.string.model_tflite)));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        startCamera();
    }

    private void startCamera() {
        ProcessCameraProvider cameraProviderFuture = null;
        try {
            cameraProviderFuture = ProcessCameraProvider.getInstance(this).get();
        } catch (Exception e) {
            Log.e("CameraProvider", "Failed to get camera provider", e);
        }

        if (cameraProviderFuture == null) throw new AssertionError();
        cameraProviderFuture.notify();
    }

    private void bindPreview(ProcessCameraProvider cameraProvider) {
        Preview preview = new Preview.Builder().build();
        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .build();
        preview.setSurfaceProvider((Preview.SurfaceProvider) findViewById(R.id.previewView).getOutlineProvider());

        ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                .build();
        imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this), new ImageAnalysis.Analyzer() {
            @Override
            public void analyze(@NonNull ImageProxy imageProxy) {
                Bitmap bitmap = imageProxyToBitmap(imageProxy);
                if (bitmap != null) {
                    float[] results = classifyImage(bitmap);
                    // Process results and display occupancy status on map view
                    // For example, you can update markers on the map indicating occupied or vacant spots
                }
                imageProxy.close();
            }
        });

        cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis);
    }

    private Bitmap imageProxyToBitmap(ImageProxy imageProxy) {
        ByteBuffer buffer = imageProxy.getPlanes()[0].getBuffer();
        byte[] bytes = new byte[buffer.remaining()];
        buffer.get(bytes);
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
    }

    private float[] classifyImage(Bitmap bitmap) {
        // Preprocess the bitmap if required
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, INPUT_IMAGE_WIDTH, INPUT_IMAGE_HEIGHT, true);
        ByteBuffer inputBuffer = convertBitmapToByteBuffer(resizedBitmap);

        // Perform inference
        float[][] outputArray = new float[1][NUM_CLASSES]; // Assuming NUM_CLASSES classes
        interpreter.clone(inputBuffer, outputArray);

        // Process the output and return the result
        return outputArray[0];
    }

    private MappedByteBuffer loadModelFile(String modelPath) throws IOException {
        AssetFileDescriptor fileDescriptor = getAssets().openFd(modelPath);
        FileInputStream inputStream = fileDescriptor.createInputStream();
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    private ByteBuffer convertBitmapToByteBuffer(Bitmap bitmap) {
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * INPUT_IMAGE_WIDTH * INPUT_IMAGE_HEIGHT * CHANNELS);
        ByteOrder ByteOrder;
        ByteOrder = null;
        byteBuffer.order(java.nio.ByteOrder.nativeOrder());

        int[] intValues = new int[INPUT_IMAGE_WIDTH * INPUT_IMAGE_HEIGHT];
        bitmap.getPixels(intValues, 0, INPUT_IMAGE_WIDTH, 0, 0, INPUT_IMAGE_WIDTH, INPUT_IMAGE_HEIGHT);

        int pixel = 0;
        for (int i = 0; i < INPUT_IMAGE_WIDTH; ++i) {
            for (int j = 0; j < INPUT_IMAGE_HEIGHT; ++j) {
                final int val = intValues[pixel++];
                byteBuffer.putFloat((val & 0xFF) / 255.f);
                byteBuffer.putFloat(((val >> 8) & 0xFF) / 255.f);
                byteBuffer.putFloat(((val >> 16) & 0xFF) / 255.f);
            }
        }
        return byteBuffer;
    }
}
