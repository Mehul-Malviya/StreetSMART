import java.io.FileInputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

public class AssetFileDescriptor {
    private FileInputStream fileInputStream;
    private FileChannel fileChannel;

    public AssetFileDescriptor(String filePath) throws IOException {
        fileInputStream = new FileInputStream(filePath);
        fileChannel = fileInputStream.getChannel();
    }

    public long getStartOffset() throws IOException {
        return fileChannel.position();
    }

    public long getDeclaredLength() throws IOException {
        return fileChannel.size();
    }

    public FileInputStream getFileInputStream() {
        return fileInputStream;
    }

    public void close() throws IOException {
        if (fileInputStream != null) {
            fileInputStream.close();
        }
        if (fileChannel != null) {
            fileChannel.close();
        }
    }
}
