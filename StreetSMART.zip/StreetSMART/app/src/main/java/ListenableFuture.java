import java.util.concurrent.Executor;

public class ListenableFuture<T> {
    private T result;
    private Exception exception;
    private boolean completed;
    private Runnable listener;
    private Executor executor;

    public void addListener(Runnable listener, Executor executor) {
        if (completed) {
            // If the computation has already completed, execute the listener immediately
            executor.execute(listener);
        } else {
            // Otherwise, store the listener and executor for later execution
            this.listener = listener;
            this.executor = executor;
        }
    }

    // Method to complete the future with a result
    public void setResult(T result) {
        this.result = result;
        this.completed = true;
        if (listener != null && executor != null) {
            executor.execute(listener);
        }
    }

    // Method to complete the future with an exception
    public void setException(Exception exception) {
        this.exception = exception;
        this.completed = true;
        if (listener != null && executor != null) {
            executor.execute(listener);
        }
    }

    // Method to get the result of the computation
    public T get() throws Exception {
        if (!completed) {
            throw new IllegalStateException("Future is not completed yet");
        }
        if (exception != null) {
            throw exception;
        }
        return result;
    }
}
